package com.polstatstis.volunteerpdt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabkomApplication {

	@Test
	void contextLoads() {
	}

}
